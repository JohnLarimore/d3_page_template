<?php include 'includes/header.php'; ?>
<h1>Start From Here</h1>
<?php include 'includes/footer.php'; ?>