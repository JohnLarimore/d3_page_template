<!DOCTYPE html>
<html>
	<head>
		<title>Template</title>
		<link rel="stylesheet" href="css/styles.css" />
		<script src="scripts/htmx.min.js"></script>
	</head>
	<body>